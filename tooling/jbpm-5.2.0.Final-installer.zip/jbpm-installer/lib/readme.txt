This location will be used to download the necessary installation files.
You can also drop them here if you don't want ANT to download them for you:

JBoss AS:
  jboss-5.1.0.GA.zip

Birt runtime engine:
  birt-runtime-2_3_2_2.zip

Eclipse: 
  eclipse-java-helios-SR2-linux-gtk.tar.gz (linux)
  eclipse-java-helios-SR2-linux-gtk-x86_64.tar.gz (linux 64-bit)
  eclipse-java-helios-SR2-win32.zip (windows)
  eclipse-java-helios-SR2-macosx-cacoa.tar.gz (mac)

Eclipse GEF:
  GEF-SDK-3.6.2.zip

jBPM:
  jbpm-#{jbpm.version}-bin.zip
  jbpm-#{jbpm.version}-eclipse-all.zip
  jbpm-#{jbpm.version}-gwt-console.zip

Drools:
  guvnor-distribution-wars-${drools.guvnor.version}-jboss-as-5.1.war
  org.drools.updatesite-${drools.eclipse.version}-assembly.zip

Designer:
  designer-#{designer.version}.war
